#1
def fordulj_orajarasi_iranyba(p):
    if (p == "É"): return "K"
    elif (p == "K"): return "D"
    elif (p == "D"): return "Ny"
    elif (p == "Ny"): return "É"
    return None
#2
def nap_nev(k):
    if (k == 0): return "Hétfő"
    elif (k == 1): return "Kedd"
    elif (k == 2): return "Szerda"
    elif (k == 3): return "Csütörtök"
    elif (k == 4): return "Péntek"
    elif (k == 5): return "Szombat"
    elif (k == 6): return "Vasárnap"
    return None
#3
def four(n):
    asad = ["Hétfő","Kedd","Szerda","Csütörtök","Péntek","Szombat","Vasárnap"]
    if n in asad:
        return asad.index(n)
    else: 
        return None
#4
def napok_hozzaadasa(nap, napokszama):
    napok = ["Hétfő","Kedd","Szerda","Csütörtök","Péntek","Szombat","Vasárnap"]
    indnap = napok.index(nap)
    vegnapszama = (indnap + napokszama) % 7
    return napok[vegnapszama]
#5
def napok_hozzaadasa(nap, napokszama):
    napok = ["Hétfő","Kedd","Szerda","Csütörtök","Péntek","Szombat","Vasárnap"]
    indnap = napok.index(nap)
    maradeknap = (napokszama % -7)
    valtozo = indnap + maradeknap
    return napok[valtozo]
#6
def honap_napja(honap):
    honapok = (["Január",31], ["Február",28], ["Március",31], ["Április",30], ["Május",31], ["Június",30], ["Július",31], ["Augusztus",31], ["Szeptember",30], ["Október",31], ["November",30], ["December",31])
    for i,h in (honapok):
        if i == honap:
            return h
    return None
#7
def masodpercre_valtas(ora, perc, masodperc):
    a = (ora * 60) * 60
    b = perc * 60
    X = a+b+masodperc
    return X
#8
def masodpercre_valtas(ora, perc, masodperc):
    import math
    a = (ora*60)*60
    c = perc*60
    X = math.floor(a+masodperc+c)
    return X
#9
def orakra_valtas(masodperc):
    if masodperc < 0:
        return None
    return (masodperc // 3600)

def percekre_valtas(masodperc):
    if masodperc < 0:
        return None
    return(masodperc % 3600 // 60)

def masodpercekre_valtas(masodperc):
    if masodperc < 0:
        return None
    return (masodperc % 3600 % 60)
#11
def osszehasonlitas(a,b):
    if a > b:
        return 1
    elif a == b:
        return 0
    return -1
#12
def atfogo(a,b):
    import math
    return math.sqrt(a**2+b**2)
#13
def meredekseg(x1, y1, x2, y2):
    return (y2-y1) / (x2 - x1)
#14
def metszespont(x1,y1,x2,y2):
    msdg = meredekseg(x1,y1,x2,y2)
    y0 = y1 - (msdg * x1)
    return y0
#15
def paros_e(n):
    if (n % 2) == 0:
        return True
    return False
#16
def paratlan_e(n):
    if (n % 2) == 0:
        return False
    return True
#17
def tenyezo_e(t, n):
    if (n % t == 0):
        return True
    return False
#17
def tobbszorose_e(t, n):
    return tenyezo_e(n, t)
#18
def celsiusra_valtas(f):
    return round((f -32) * 5/9)
#19
def fahrenheitre_valtas(c):
    return round(c * 9/5 +32)
#20
