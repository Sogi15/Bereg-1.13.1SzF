from unitTesztSajat import teszt
from feladatok import fordulj_orajarasi_iranyba, nap_nev, four, napok_hozzaadasa, napok_hozzaadasa, honap_napja, masodpercre_valtas, masodpercre_valtas, masodpercekre_valtas, percekre_valtas, orakra_valtas, osszehasonlitas, atfogo, meredekseg, metszespont, paros_e, paratlan_e, tenyezo_e, tobbszorose_e, celsiusra_valtas, fahrenheitre_valtas
# feladat10 azért nincs, mert csak a tesztkészlet eredményeit kellett megmagyarázni

#6.9.1
if False:
    teszt(fordulj_orajarasi_iranyba("É") == "K")
    teszt(fordulj_orajarasi_iranyba("K") == "D")
    teszt(fordulj_orajarasi_iranyba("D") == "Ny")
    teszt(fordulj_orajarasi_iranyba("Ny") == "É")
    teszt(fordulj_orajarasi_iranyba("x") == None)
#6.9.2
if False:
    teszt(nap_nev(0) == "Hétfő")
    teszt(nap_nev(1) == "Kedd")
    teszt(nap_nev(2) == "Szerda")
    teszt(nap_nev(3) == "Csütörtök")
    teszt(nap_nev(4) == "Péntek")
    teszt(nap_nev(5) == "Szombat")
    teszt(nap_nev(6) == "Vasárnap")
    teszt(nap_nev(7) == None)
#6.9.3
if False:
    teszt(four("Hétfő") == 0)
    teszt(four("Kedd") == 1)
    teszt(four("Szerda") == 2)
    teszt(four("Csütörtök") == 3)
    teszt(four("Péntek") == 4)
    teszt(four("Szombat") == 5)
    teszt(four("Vasárnap") == 6)
    teszt(four("x") == None)
#6.9.4
if False:
    teszt(napok_hozzaadasa("Hétfő", 4) ==  "Péntek")
    teszt(napok_hozzaadasa("Kedd", 0) == "Kedd")
    teszt(napok_hozzaadasa("Kedd", 14) == "Kedd")
    teszt(napok_hozzaadasa("Vasárnap", 100) == "Kedd")
#6.9.5
if False:
    teszt(napok_hozzaadasa("Vasárnap", -1) == "Szombat")
    teszt(napok_hozzaadasa("Vasárnap", -7) == "Vasárnap")
    teszt(napok_hozzaadasa("Kedd", -100) == "Vasárnap")
#6.9.6
if False:
    teszt(honap_napja("Február") == 28)
    teszt(honap_napja("November") == 30)
    teszt(honap_napja("December") == 31)
#6.9.7
if False:
    teszt(masodpercre_valtas(2, 30, 10) == 9010)
    teszt(masodpercre_valtas(2, 0, 0) == 7200)
    teszt(masodpercre_valtas(0, 2, 0) == 120)
    teszt(masodpercre_valtas(0, 0, 42) == 42)
    teszt(masodpercre_valtas(0, -10, 10) == -590)
#6.9.8
if False:
    teszt(masodpercre_valtas(2.5, 0, 10.71) == 9010)
    teszt(masodpercre_valtas(2.433,0,0) == 8758)
#6.9.9
if False:
    teszt(orakra_valtas(9010) == 2)
    teszt(percekre_valtas(9010) == 30)
    teszt(masodpercekre_valtas(9010) == 10)
#6.9.10
if False:
    teszt(3 % 4 == 0) #Sikertelen, mert 3 nem osztható úgy 4-el, hogy egész számot kapjunk mivel 0,75* van meg benne
    teszt(3 % 4 == 3) #Sikeres, mert maradékos osztásnál 3 a maradék
    teszt(3 / 4 == 0) #Sikertelen, mert 3 nem osztható 4 el
    teszt(3 // 4 == 0) #Sikeres, mert 0,75 jön ki az eredmény azért 0, mert egész számra alakítja 
    teszt(3+4*2 == 14) # Sikertelen, mert 11 a helyes válasz
    teszt(4-2+2 == 0) # Sikertelen, mert 4 lesz a válasz
    teszt(len("helló, világ!") == 13) #azért lesz 13 és helyes, mert 13 karakter a "Helló, Világ!"
#6.9.11
if False:
    teszt(osszehasonlitas(5, 4) == 1)
    teszt(osszehasonlitas(7, 7) == 0)
    teszt(osszehasonlitas(2, 3) == -1)
    teszt(osszehasonlitas(42, 1) == 1)
#6.9.12
if False:
    teszt(atfogo(3, 4) == 5.0)
    teszt(atfogo(12, 5) == 13.0)
    teszt(atfogo(24, 7) == 25.0)
    teszt(atfogo(24, 7) == 25.0)
#6.9.13
if False:
    teszt(meredekseg(5, 3, 4, 2) == 1.0)
    teszt(meredekseg(1, 2, 3, 2) == 0.0)
    teszt(meredekseg(1, 2, 3, 3) == 0.5)
    teszt(meredekseg(2, 4, 1, 2) == 2.0)
#6.9.14
if False:
    teszt(metszespont(1, 6, 3, 12) == 3.0)
    teszt(metszespont(6, 1, 1, 6) == 7.0)
    teszt(metszespont(4, 6, 12, 8) == 5.0)
#6.9.15
if False:
    teszt(paros_e(10) == True)
    teszt(paros_e(11) == False)
    teszt(paros_e(0) == True)
if False:
    teszt(paratlan_e(10) == False)
    teszt(paratlan_e(11) == True)
    teszt(paratlan_e(0) == False)
#6.9.16
if False:
    teszt(tenyezo_e(3, 12))
    teszt(not tenyezo_e(5, 12))
    teszt(tenyezo_e(7, 14))
    teszt(not tenyezo_e(7, 15))
    teszt(tenyezo_e(1, 15))
    teszt(tenyezo_e(15, 15))
    teszt(not tenyezo_e(25, 15))
#6.9.17
if False:
    teszt(tobbszorose_e(12, 3))
    teszt(tobbszorose_e(12, 4))
    teszt(not tobbszorose_e(12, 5))
    teszt(tobbszorose_e(12, 6))
    teszt(not tobbszorose_e(12, 7))
#6.9.18
if False:
    teszt(celsiusra_valtas(212) == 100) # A víz forráspontja
    teszt(celsiusra_valtas(32) == 0) # A víz fagyáspontja
    teszt(celsiusra_valtas(-40) == -40) # Ó, micsoda érdekes eset!
    teszt(celsiusra_valtas(36) == 2)
    teszt(celsiusra_valtas(37) == 3)
    teszt(celsiusra_valtas(38) == 3)
    teszt(celsiusra_valtas(39) == 4)
#6.9.19
if False:
    teszt(fahrenheitre_valtas(0) == 32)
    teszt(fahrenheitre_valtas(100) == 212)
    teszt(fahrenheitre_valtas(-40) == -40)
    teszt(fahrenheitre_valtas(12) == 54)
    teszt(fahrenheitre_valtas(18) == 64)
    teszt(fahrenheitre_valtas(-48) == -54)