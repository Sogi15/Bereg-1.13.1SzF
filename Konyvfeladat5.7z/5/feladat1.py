n =  int(input("Írd be a számot (0-6): "))
napok = ["Hétfő","Kedd","Szerda","Csütörtök","Péntek","Szombat","Vasárnap"]
if n > 6:
    print("Kérlek csak 0-6-ig add meg a számot")
elif n < 0:
    print("Minusz számot nem fogadhatok el!")
elif n >= 0 and n <= 6:
    nap = napok[n]
    print("A beírt számnak megfelelő nap:", nap)

def napok_hozzaadasa(nap, napokszama):
    napok = ["Hétfő","Kedd","Szerda","Csütörtök","Péntek","Szombat","Vasárnap"]
    indnap = napok.index(nap)
    maradeknap = (napokszama % -7)
    valtozo = indnap + maradeknap
    return napok[valtozo]