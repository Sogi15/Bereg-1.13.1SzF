pont = float(input("Írd be a vizsgán szerzett pontszámaidat:"))
jegy = ["Elégtelen", "Elégséges", "Közepes", "Jó", "Jeles"]

if pont >= 90:
    print("Értékelés:", jegy[4], "Pontjaid:", pont,"pont")
elif pont >= 80:
    print("Értékelés:", jegy[3], "Pontjaid:", pont,"pont")
elif pont >= 70:
    print("Értékelés:", jegy[2], "Pontjaid:", pont,"pont")
elif pont >= 60:
    print("Értékelés:", jegy[1], "Pontjaid:", pont,"pont")
elif pont >= 0:
    print("Értékelés:", jegy[0], "Pontjaid:", pont,"pont")
else:
    print("Hogy érhettél el",pont,"pontot, mikor 0-100 pontos volt a dolgozat!? Kérlek a valós számot add meg!")