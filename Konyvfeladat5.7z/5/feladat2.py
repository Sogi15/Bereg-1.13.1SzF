n =  int(input("Hanyadik napon indultál? (0-6): "))
napok = ["Hétfő","Kedd","Szerda","Csütörtök","Péntek","Szombat","Vasárnap"]
if n >= 0 and n <= 6:
    mn = int(input("Hány napig leszel ott?: "))
    nap = napok[n]
    print("Ezen a napon indultál: ", nap)
    indnap = napok.index(nap)
    maradeknap = (mn % -7)
    valtozo = indnap + maradeknap
    print("Ennyi napig leszel ott: ", mn)
    print("Ezen a napon jössz haza: ", napok[valtozo])
elif n < 0:
    print("Minusz számot nem fogadhatok el!")
elif n > 6:
    print("Csak 0-6-ig válassz számot!")
