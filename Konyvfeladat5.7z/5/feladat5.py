import turtle
Eszti = turtle.Turtle()
window = turtle.Screen()
window.bgcolor("white")
window.title("Diagram rajzolas")
Eszti.speed(10)
Eszti.pensize(3)
Eszti.penup()
Eszti.goto(-100, -50)
Eszti.pendown()

xs = [48, -117, 200, 240, 160, 260, -220]
def rajzolj_oszlopot(t,magassag):
    if magassag >= 200:
        Eszti.color("black", "red")
    elif magassag >= 100:
        Eszti.color("black", "yellow")
    else:
        Eszti.color("black", "green")
    t.begin_fill()
    t.left(90)
    t.forward(magassag)
    if magassag < 0:
        t.write(" "+str(magassag))
    else:
        t.write(" "+str(magassag))
    t.right(90)
    t.forward(40)
    t.right(90)
    t.forward(magassag)
    t.left(90)
    t.end_fill()
    t.penup()
    t.forward(10)
    t.pendown()
for m in xs:
    rajzolj_oszlopot(Eszti, m)

window.mainloop()