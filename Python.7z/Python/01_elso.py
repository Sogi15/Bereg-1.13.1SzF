# Ez az első programunk
# print mint kiírás
print("""Helló világ! Ez egy hosszú sor
yyyyyyyyyyyyyyyy""")
