# változók
egesz = 32
tizedes = 3.25
szoveg = "szoveg"

print("egesz típusa: ")
print(type(egesz))
print("tizedes típusa: ")
print(type(tizedes))
print("szoveg típusa: ")
print(type(szoveg))