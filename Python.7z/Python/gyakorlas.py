valasztas = 0
if valasztas == "a":
    valasztas += 12
elif valasztas == "b":
    valasztas -= 12
elif valasztas == "c":
    valasztas /= 12
else: 
    print("Érvénytelen választás.")