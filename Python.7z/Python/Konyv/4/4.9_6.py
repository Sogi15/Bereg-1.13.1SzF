import turtle
window = turtle.Screen()
window.bgcolor("black")
window.title("Négyzetek rajzolása")
toll = turtle.Turtle()
toll.pencolor("orange")
toll.speed(5)
toll.pensize(3)

for i in range(3):
    toll.forward(100)
    toll.left(120)
    toll.forward(100)


window.mainloop()