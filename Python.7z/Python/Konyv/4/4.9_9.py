import turtle
window = turtle.Screen()
window.bgcolor("black")
window.title("Csillag rajzolás")

toll = turtle.Turtle()
toll.speed(3)
toll.pensize(3)
toll.pencolor("limegreen")

for i in range(5):
        toll.forward(100)
        toll.right(144)


window.mainloop()