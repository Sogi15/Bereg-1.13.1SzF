import turtle
window = turtle.Screen()
window.bgcolor("black")
window.title("Csillag rajzolás")

toll = turtle.Turtle()
toll.speed(10)
toll.pensize(3)
toll.pencolor("limegreen")
def rajzolas():
    for i in range(5):
        toll.forward(100)
        toll.right(144)
def ugras(x, y):
    for i in range(1):
        toll.penup()
        toll.goto(x, y)
        toll.pendown()
rajzolas()
ugras(-100, -100)
rajzolas()
ugras(100, -100)
rajzolas()
ugras(-100, 100)
rajzolas()
ugras(100, 100)
rajzolas()


window.mainloop()