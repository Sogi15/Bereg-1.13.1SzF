import turtle
window = turtle.Screen()
window.bgcolor("black")
window.title("Négyzet spirál")

toll = turtle.Turtle()
toll.speed(3)
toll.pensize(3)

def negyzetek(hosszusag, szog, oldalak):
        toll.pencolor("red")
        for i in range(oldalak):
            toll.forward(hosszusag)
            toll.left(szog)

for i in range(2):
    negyzetek(100,45,4)


window.mainloop()