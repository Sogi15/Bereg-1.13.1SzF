import turtle
# ablak
window = turtle.Screen()
window.bgcolor("black")
window.title("Négyzetek rajzolása")

#toll létrehozása
toll = turtle.Turtle()
toll.speed(3)
toll.pensize(3)

def negyzet(toll, hossz, szin, pozicio):
    toll.color(szin)
    toll.penup()
    toll.goto(pozicio, 0)
    toll.pendown()
    for i in range(4):
        toll.forward(30)
        toll.left(90)

x = 0
for i in "red", "green", "blue", "yellow":
    negyzet(toll, 30, i, x)
    x += 40
toll.penup()
toll.goto(180, 0)
window.mainloop()