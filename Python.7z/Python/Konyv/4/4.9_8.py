from math import pi
r = float(input ("Írd be a kör sugarát: "))
if r == 0:
    print(r, "Sugarú kör nem létezik!")
elif r < 0:
    print("Sugár: " + str(r) + " Terület: " + str(pi * r **2))
    print("Minusz sugarú a kör")
else:
    print("A kör sugara: " + str(r) + " a területe pedig: " +str(pi * r **2))