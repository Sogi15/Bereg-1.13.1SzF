print("Összegzés")
n = int(input("n = "))
osszeg = n
for i in range(n):
    osszeg += i
print(n, "Összegzés", osszeg)