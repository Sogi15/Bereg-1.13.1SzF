import turtle
toll = turtle.Turtle()
ablak = turtle.Screen()
ablak.bgcolor("black")
toll.pensize(1)
toll.speed(100)
toll.pencolor("cyan")

oldal = 200
for i in  range(100):
    toll.forward(oldal)
    toll.left(90)
    oldal = oldal - 2
toll.penup()
toll.goto(-300, 0)
x = 200
toll.pendown()
for i in  range(100):
    toll.forward(x)
    toll.left(89)
    x = x - 2

ablak.mainloop()