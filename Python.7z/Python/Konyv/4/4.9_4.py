import turtle
toll = turtle.Turtle()
ablak = turtle.Screen()
ablak.bgcolor("black")
toll.pensize(4)
toll.speed(100)
toll.pencolor("magenta")

def spiral():
    for i in range(4):
        toll.forward(150)
        toll.right(90)

for i in range(20):
    spiral()
    toll.left(18)

ablak.mainloop()