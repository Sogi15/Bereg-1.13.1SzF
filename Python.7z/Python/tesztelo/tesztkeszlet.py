from unitTesztSajat import teszt
from feladatA import fordulj_orajarasi_iranyba, nap_nev, nap_nevT, third, four

if False:
    teszt(fordulj_orajarasi_iranyba("É") == "K")
    teszt(fordulj_orajarasi_iranyba("K") == "D")
    teszt(fordulj_orajarasi_iranyba("D") == "Ny")
    teszt(fordulj_orajarasi_iranyba("Ny") == "É")
    teszt(fordulj_orajarasi_iranyba("x") == None)
    
if False:
    teszt(nap_nev(0) == "Hétfő")
    teszt(nap_nev(1) == "Kedd")
    teszt(nap_nev(2) == "Szerda")
    teszt(nap_nev(3) == "Csütörtök")
    teszt(nap_nev(4) == "Péntek")
    teszt(nap_nev(5) == "Szombat")
    teszt(nap_nev(6) == "Vasárnap")
    teszt(nap_nev(7) == None)

if False:
    teszt(nap_nevT(0) == "Hétfő")
    teszt(nap_nevT(1) == "Kedd")
    teszt(nap_nevT(2) == "Szerda")
    teszt(nap_nevT(3) == "Csütörtök")
    teszt(nap_nevT(4) == "Péntek")
    teszt(nap_nevT(5) == "Szombat")
    teszt(nap_nevT(6) == "Vasárnap")
    teszt(nap_nevT(7) == None)

if False:
    teszt(third("Hétfő") == 0)
    teszt(third("Kedd") == 1)
    teszt(third("Szerda") == 2)
    teszt(third("Csütörtök") == 3)
    teszt(third("Péntek") == 4)
    teszt(third("Szombat") == 5)
    teszt(third("Vasárnap") == 6)
    teszt(third("x") == None)

if True:
    teszt(four("Hétfő") == 0)
    teszt(four("Kedd") == 1)
    teszt(four("Szerda") == 2)
    teszt(four("Csütörtök") == 3)
    teszt(four("Péntek") == 4)
    teszt(four("Szombat") == 5)
    teszt(four("Vasárnap") == 6)
    teszt(four("x") == None)