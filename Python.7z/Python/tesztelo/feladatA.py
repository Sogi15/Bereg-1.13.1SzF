#1. Az égtájak rövid néven: "É", "K", "Ny", "D".
# Írjunk függvényt "fordulj_orajarasi_iranyba()"
# névvel, ami a paraméterként megadott égtáj után következik. Rossz paraméter esetén None értéket ad vissza

def fordulj_orajarasi_iranyba(p):
    if (p == "É"): return "K"
    elif (p == "K"): return "D"
    elif (p == "D"): return "Ny"
    elif (p == "Ny"): return "É"
    return None

# 2. Írj egy nap_nev függvényt, amely a [0, 6] tartományban eső egész számot vár
# paraméterenként, és visszaadja az adott sorszámú nap nevét. A 0. nap a hétfő. Még egyszer
# ha nem várt érték érkezik, akkor None értékkel tér vissza.

def nap_nev(k):
    if (k == 0): return "Hétfő"
    elif (k == 1): return "Kedd"
    elif (k == 2): return "Szerda"
    elif (k == 3): return "Csütörtök"
    elif (k == 4): return "Péntek"
    elif (k == 5): return "Szombat"
    elif (k == 6): return "Vasárnap"
    return None

# 2.ik feladat tömbbel való megoldása:
def nap_nevT(t):
    napok = ["Hétfő","Kedd","Szerda","Csütörtök","Péntek","Szombat","Vasárnap"]
    if t > 6:
        return None
    return napok[t]

def third(a):
    if (a == "Hétfő"): return 0
    elif (a == "Kedd"): return 1
    elif (a == "Szerda"): return 2
    elif (a == "Csütörtök"): return 3
    elif (a == "Péntek"): return 4
    elif (a == "Szombat"): return 5
    elif (a == "Vasárnap"): return 6
    return None

def four(n):
    asad = ["Hétfő","Kedd","Szerda","Csütörtök","Péntek","Szombat","Vasárnap"]
    if n in asad:
        return asad.index(n)
    else: 
        return None